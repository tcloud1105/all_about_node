# ChatCAT 2.0 (All About NodeJS by Sachin Bhatnagar (@sachinbee))
## 1. To install, simply run 'npm install' or 'npm i' from within the folder.
## 2. Configure the app/config/development.json file to include access credentials to services.
## 3. To run the app, type 'npm start'.